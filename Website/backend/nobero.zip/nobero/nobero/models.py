
from django.db import models

class Product(models.Model):
    name = 